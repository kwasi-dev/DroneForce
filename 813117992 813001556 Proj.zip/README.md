# DroneForce

Finally achieved liftoff!! 11:04 14-APR-2016

Completed:
Draft of sensor class
Sensor class calculations to give readings in terms of speed on all 3 axis
Integration of API finished
Remove files that were not used
Remove unused imports

Need to do:
Code movements other than takeoff	
Document code more fluently
Add progress indicators wrt connection, waiting for LANDED state, etc 
Properly request all permissions
Add supports for more drones later on after all of the above
Compile and run on watch